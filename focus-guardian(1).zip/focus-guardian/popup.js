// Popup script for Focus Guardian

const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusBadge = document.getElementById('statusBadge');
const focusWebsiteEl = document.getElementById('focusWebsite');
const currentTabEl = document.getElementById('currentTab');

// Get current tab info
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Update UI based on monitoring status
function updateUI(status) {
  if (status.isMonitoring) {
    statusBadge.textContent = 'Active';
    statusBadge.className = 'badge active';
    focusWebsiteEl.textContent = status.focusWebsite || 'Unknown';
    focusWebsiteEl.className = 'status-value';
    startBtn.disabled = true;
    stopBtn.disabled = false;
  } else {
    statusBadge.textContent = 'Inactive';
    statusBadge.className = 'badge inactive';
    focusWebsiteEl.textContent = 'Not set';
    focusWebsiteEl.className = 'status-value inactive';
    startBtn.disabled = false;
    stopBtn.disabled = true;
  }
}

// Initialize popup
async function init() {
  // Get current tab
  const tab = await getCurrentTab();
  if (tab && tab.url) {
    const url = new URL(tab.url);
    currentTabEl.textContent = url.hostname;
  }
  
  // Get monitoring status
  chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
    updateUI(response);
  });
}

// Start monitoring
startBtn.addEventListener('click', async () => {
  const tab = await getCurrentTab();
  
  if (!tab || !tab.url) {
    alert('Cannot monitor this tab');
    return;
  }
  
  // Don't allow monitoring on chrome:// pages
  if (tab.url.startsWith('chrome://') || 
      tab.url.startsWith('about:') || 
      tab.url.startsWith('edge://')) {
    alert('Cannot monitor browser internal pages');
    return;
  }
  
  chrome.runtime.sendMessage({
    action: 'startMonitoring',
    website: tab.url,
    tabId: tab.id
  }, (response) => {
    if (response.success) {
      updateUI({
        isMonitoring: true,
        focusWebsite: tab.url
      });
    }
  });
});

// Stop monitoring
stopBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'stopMonitoring' }, (response) => {
    if (response.success) {
      updateUI({
        isMonitoring: false,
        focusWebsite: null
      });
    }
  });
});

// Test alert
document.getElementById('testBtn').addEventListener('click', async () => {
  const tab = await getCurrentTab();
  
  // Show browser notification
  chrome.notifications.create('test-' + Date.now(), {
    type: 'basic',
    iconUrl: 'icon128.png',
    title: '🧪 Test Alert',
    message: 'This is what a focus alert looks like!',
    priority: 2,
    requireInteraction: false
  });
  
  // Show on-page alert if we can
  if (tab && tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const alert = document.createElement('div');
        alert.innerHTML = `
          <div style="
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 20px 24px;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            z-index: 999999;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            animation: slideIn 0.3s ease-out;
          ">
            <div style="font-size: 24px; margin-bottom: 8px;">🧪 Test Alert</div>
            <div style="font-size: 14px; line-height: 1.5;">
              This is what you'll see when you navigate away from your focus site!
            </div>
            <button onclick="this.parentElement.parentElement.remove()" style="
              margin-top: 12px;
              background: rgba(255,255,255,0.2);
              border: 1px solid rgba(255,255,255,0.3);
              color: white;
              padding: 8px 16px;
              border-radius: 6px;
              cursor: pointer;
              font-size: 12px;
              font-weight: 600;
            ">Dismiss</button>
          </div>
          <style>
            @keyframes slideIn {
              from { transform: translateX(400px); opacity: 0; }
              to { transform: translateX(0); opacity: 1; }
            }
          </style>
        `;
        document.body.appendChild(alert);
        setTimeout(() => alert.remove(), 5000);
      }
    }).catch(err => console.log('Could not show on-page alert:', err));
  }
});

// Initialize on load
init();
