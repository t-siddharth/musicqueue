// Background service worker for Focus Guardian

let focusWebsite = null;
let isMonitoring = false;
let originalTabId = null;

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startMonitoring') {
    focusWebsite = message.website;
    originalTabId = message.tabId;
    isMonitoring = true;
    
    console.log('Started monitoring. Focus website:', focusWebsite);
    
    chrome.storage.local.set({
      focusWebsite: focusWebsite,
      isMonitoring: true,
      originalTabId: originalTabId
    });
    
    sendResponse({ success: true });
  } else if (message.action === 'stopMonitoring') {
    isMonitoring = false;
    focusWebsite = null;
    originalTabId = null;
    
    chrome.storage.local.set({
      isMonitoring: false,
      focusWebsite: null,
      originalTabId: null
    });
    
    console.log('Stopped monitoring');
    sendResponse({ success: true });
  } else if (message.action === 'getStatus') {
    sendResponse({
      isMonitoring: isMonitoring,
      focusWebsite: focusWebsite
    });
  }
  
  return true; // Keep message channel open for async response
});

// Load state on startup
chrome.storage.local.get(['focusWebsite', 'isMonitoring', 'originalTabId'], (result) => {
  if (result.isMonitoring) {
    focusWebsite = result.focusWebsite;
    isMonitoring = result.isMonitoring;
    originalTabId = result.originalTabId;
    console.log('Restored monitoring state:', { focusWebsite, isMonitoring });
  }
});

// Extract domain from URL
function getDomain(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch (e) {
    return null;
  }
}

// Check if URL is on the focus website
function isOnFocusWebsite(url) {
  if (!focusWebsite || !url) return true;
  
  const currentDomain = getDomain(url);
  const focusDomain = getDomain(focusWebsite);
  
  if (!currentDomain || !focusDomain) return true;
  
  // Check if domains match (including subdomains)
  return currentDomain === focusDomain || currentDomain.endsWith('.' + focusDomain);
}

// Show notification when user navigates away
function showAlert(tabId, url) {
  const currentDomain = getDomain(url);
  const focusDomain = getDomain(focusWebsite);
  
  console.log('🚨 ALERT TRIGGERED!');
  console.log('You navigated from:', focusDomain);
  console.log('To:', currentDomain);
  
  // Create notification
  chrome.notifications.create('focus-alert-' + Date.now(), {
    type: 'basic',
    iconUrl: 'icon128.png',
    title: '⚠️ Focus Alert!',
    message: `You've left ${focusDomain}!\nNow on: ${currentDomain}`,
    priority: 2,
    requireInteraction: true,
    silent: false
  }, (notificationId) => {
    if (chrome.runtime.lastError) {
      console.error('Notification error:', chrome.runtime.lastError);
    } else {
      console.log('Notification created:', notificationId);
    }
  });
  
  // Update badge
  chrome.action.setBadgeText({ text: '!', tabId: tabId });
  chrome.action.setBadgeBackgroundColor({ color: '#FF0000', tabId: tabId });
  
  // Inject content script to show on-page alert
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: showPageAlert,
    args: [focusDomain, currentDomain]
  }).catch(err => {
    console.log('Could not inject script:', err);
  });
}

// Function to inject into page for visual alert
function showPageAlert(focusDomain, currentDomain) {
  // Remove any existing alert
  const existingAlert = document.getElementById('focus-guardian-alert');
  if (existingAlert) {
    existingAlert.remove();
  }
  
  // Create alert element
  const alert = document.createElement('div');
  alert.id = 'focus-guardian-alert';
  alert.innerHTML = `
    <div style="
      position: fixed;
      top: 20px;
      right: 20px;
      background: linear-gradient(135deg, #ff6b6b, #ee5a6f);
      color: white;
      padding: 20px 24px;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 350px;
      animation: slideIn 0.3s ease-out;
    ">
      <div style="font-size: 24px; margin-bottom: 8px;">⚠️ Focus Alert!</div>
      <div style="font-size: 14px; line-height: 1.5; margin-bottom: 12px;">
        You've navigated away from <strong>${focusDomain}</strong>
      </div>
      <div style="font-size: 13px; opacity: 0.9;">
        Now on: ${currentDomain}
      </div>
      <button onclick="this.parentElement.parentElement.remove()" style="
        margin-top: 12px;
        background: rgba(255,255,255,0.2);
        border: 1px solid rgba(255,255,255,0.3);
        color: white;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 12px;
        font-weight: 600;
      ">Dismiss</button>
    </div>
    <style>
      @keyframes slideIn {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    </style>
  `;
  
  document.body.appendChild(alert);
  
  // Auto-dismiss after 10 seconds
  setTimeout(() => {
    if (alert.parentElement) {
      alert.style.opacity = '0';
      alert.style.transform = 'translateX(400px)';
      alert.style.transition = 'all 0.3s ease-out';
      setTimeout(() => alert.remove(), 300);
    }
  }, 10000);
  
  console.log('🚨 Focus Guardian: You left', focusDomain, '- now on', currentDomain);
}

// Listen for tab updates (navigation)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!isMonitoring) return;
  
  // Only check when the page has finished loading
  if (changeInfo.status === 'complete' && tab.url) {
    console.log('Tab updated:', tab.url);
    
    // Ignore chrome:// and other internal pages
    if (tab.url.startsWith('chrome://') || 
        tab.url.startsWith('about:') || 
        tab.url.startsWith('edge://')) {
      console.log('Ignoring internal page');
      return;
    }
    
    const onFocus = isOnFocusWebsite(tab.url);
    console.log('On focus website?', onFocus);
    console.log('Focus website:', focusWebsite);
    console.log('Current URL:', tab.url);
    
    if (!onFocus) {
      console.log('🚨 TRIGGERING ALERT!');
      showAlert(tabId, tab.url);
    } else {
      // Clear badge when back on focus website
      chrome.action.setBadgeText({ text: '' });
      console.log('✅ Back on focus website');
    }
  }
});

// Listen for tab activation (switching between tabs)
chrome.tabs.onActivated.addListener((activeInfo) => {
  if (!isMonitoring) return;
  
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab.url) {
      // Ignore internal pages
      if (tab.url.startsWith('chrome://') || 
          tab.url.startsWith('about:') || 
          tab.url.startsWith('edge://')) {
        return;
      }
      
      if (!isOnFocusWebsite(tab.url)) {
        showAlert(activeInfo.tabId, tab.url);
      } else {
        chrome.action.setBadgeText({ text: '' });
      }
    }
  });
});

console.log('Focus Guardian background service worker loaded');
