

# Emotion Monitoring Dashboard — Full Experience

## Overview
A mental health-focused dashboard that tracks your friend's emotions in real-time, shows their recent music listening history to infer mood, and sends you alerts when they might need support. Built with Lovable Cloud (Supabase) for authentication, database, and notifications.

---

## Phase 1: Foundation & Auth
- **User accounts** with email signup/login via Lovable Cloud (Supabase Auth)
- **User profiles** table storing name, avatar, and preferences
- **Friend connections** — ability to add friends by email/invite link and accept/decline requests
- **Dark/light mode** toggle with a calming, empathetic design language throughout

## Phase 2: Core Emotion Dashboard
- **Real-time emotion display** showing 6 primary emotions (Happy, Sad, Angry, Anxious, Calm, Excited) as animated, color-coded bubbles that grow/shrink with intensity
- **Dominant emotion** shown prominently with emoji and overall mood score
- **Simulated emotion data** to start — realistic mock data that updates every few seconds so the UI feels alive (ready to swap in a real voice analysis API later)
- **Pulse animations** and smooth gradient transitions for an immersive feel

## Phase 3: Emotion Timeline & History
- **Interactive line chart** (Recharts) showing emotion trends over time
- **Time filters**: Last hour, Today, This week, This month
- **Tap/click data points** for detail view
- **Pattern annotations** highlighting notable spikes

## Phase 4: Music-Based Mood Tracking
- **Recent music section** showing the last few songs your friend listened to
- **Manual music logging** — users can add songs they've been listening to (title, artist)
- **AI-powered mood inference** using Lovable AI — analyzes recent song choices to suggest what mood they might reflect (e.g., "Listening to a lot of slow ballads — might be feeling reflective")
- **Music mood timeline** correlating music choices with emotion data

## Phase 5: Alert & Notification System
- **Threshold settings** — configure which emotions trigger alerts and at what intensity level
- **Contact management** — add trusted contacts (name, email, relationship)
- **Real email notifications** via a Supabase Edge Function when thresholds are crossed
- **Notification log** — history of all alerts sent with timestamps
- **"Send check-in now"** manual button to reach out immediately
- **Toggle** to enable/disable notifications

## Phase 6: Insights & Analytics
- **Daily/weekly mood score** calculation
- **AI-generated insights** like "Your friend tends to feel anxious in the evenings" using Lovable AI
- **Emotion balance** — positive vs negative emotion breakdown
- **Streaks** — consecutive days of positive emotions
- **Weekly summary cards** with beautiful metrics

## Phase 7: Settings & Polish
- **Settings panel**: notification preferences, data retention, alert sensitivity, privacy controls
- **Export data** (CSV) for sharing with healthcare providers
- **Responsive mobile-first design** — stacked cards on mobile, bottom navigation, swipe gestures
- **Loading skeletons**, empty states, error handling with retry
- **Accessibility**: keyboard navigation, screen reader support, high contrast mode

---

## Design Direction
- **Calming, empathetic color palette**: warm yellows for happy, cool blues for sad, reds for anger, oranges for anxiety, lavender for calm, bright gold for excitement
- **Soft gradient backgrounds**, card-based layout, smooth animations
- **Inspired by**: Calm, Apple Health, Oura Ring — clean, trustworthy, and non-clinical

## Tech Approach
- **Lovable Cloud** for database, auth, edge functions, and secrets
- **Lovable AI** for mood inference from music and generating insights
- **Recharts** for timeline visualizations
- **Supabase Edge Functions** for sending notification emails and AI calls
- **Real-time subscriptions** for live emotion updates between friends

