
-- Profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  display_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email));
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Friend connections
CREATE TYPE public.friend_status AS ENUM ('pending', 'accepted', 'declined');

CREATE TABLE public.friend_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  addressee_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status public.friend_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(requester_id, addressee_id)
);

ALTER TABLE public.friend_connections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own connections" ON public.friend_connections
  FOR SELECT USING (auth.uid() = requester_id OR auth.uid() = addressee_id);
CREATE POLICY "Users can create connections" ON public.friend_connections
  FOR INSERT WITH CHECK (auth.uid() = requester_id);
CREATE POLICY "Addressee can update connection" ON public.friend_connections
  FOR UPDATE USING (auth.uid() = addressee_id);

-- Emotion types
CREATE TYPE public.emotion_type AS ENUM ('happy', 'sad', 'angry', 'anxious', 'calm', 'excited');

-- Emotion records
CREATE TABLE public.emotion_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  emotion public.emotion_type NOT NULL,
  intensity SMALLINT NOT NULL CHECK (intensity BETWEEN 0 AND 100),
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.emotion_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own emotions" ON public.emotion_records
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own emotions" ON public.emotion_records
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Friends can view each other's emotions
CREATE POLICY "Friends can view emotions" ON public.emotion_records
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.friend_connections
      WHERE status = 'accepted'
      AND ((requester_id = auth.uid() AND addressee_id = emotion_records.user_id)
        OR (addressee_id = auth.uid() AND requester_id = emotion_records.user_id))
    )
  );

-- Music logs
CREATE TABLE public.music_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  artist TEXT NOT NULL,
  mood_inference TEXT,
  logged_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.music_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own music" ON public.music_logs
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own music" ON public.music_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Friends can view music" ON public.music_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.friend_connections
      WHERE status = 'accepted'
      AND ((requester_id = auth.uid() AND addressee_id = music_logs.user_id)
        OR (addressee_id = auth.uid() AND requester_id = music_logs.user_id))
    )
  );

-- Notification contacts
CREATE TABLE public.notification_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  relationship TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.notification_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own contacts" ON public.notification_contacts
  FOR ALL USING (auth.uid() = user_id);

-- Alert thresholds
CREATE TABLE public.alert_thresholds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  emotion public.emotion_type NOT NULL,
  threshold SMALLINT NOT NULL CHECK (threshold BETWEEN 0 AND 100),
  enabled BOOLEAN NOT NULL DEFAULT true,
  UNIQUE(user_id, emotion)
);

ALTER TABLE public.alert_thresholds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own thresholds" ON public.alert_thresholds
  FOR ALL USING (auth.uid() = user_id);

-- Notification log
CREATE TABLE public.notification_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  contact_id UUID REFERENCES public.notification_contacts(id) ON DELETE SET NULL,
  emotion public.emotion_type NOT NULL,
  intensity SMALLINT NOT NULL,
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  message TEXT
);

ALTER TABLE public.notification_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications" ON public.notification_log
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own notifications" ON public.notification_log
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Enable realtime for emotion records
ALTER PUBLICATION supabase_realtime ADD TABLE public.emotion_records;

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_friend_connections_updated_at BEFORE UPDATE ON public.friend_connections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Allow users to find others by email for friend requests
CREATE POLICY "Users can search profiles" ON public.profiles FOR SELECT USING (true);
