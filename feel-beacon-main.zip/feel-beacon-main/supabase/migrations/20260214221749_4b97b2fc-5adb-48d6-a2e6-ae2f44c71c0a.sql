
-- Widen stress column to hold 0-100 values
ALTER TABLE public.stress_readings 
  ALTER COLUMN stress TYPE numeric(5,2),
  DROP CONSTRAINT IF EXISTS stress_readings_stress_check;

ALTER TABLE public.stress_readings
  ADD CONSTRAINT stress_readings_stress_check CHECK (stress >= 0 AND stress <= 100);
