
-- Use float to avoid numeric overflow issues entirely
ALTER TABLE public.stress_readings 
  ALTER COLUMN stress TYPE double precision;

-- Update constraint  
ALTER TABLE public.stress_readings
  DROP CONSTRAINT IF EXISTS stress_readings_stress_check;
