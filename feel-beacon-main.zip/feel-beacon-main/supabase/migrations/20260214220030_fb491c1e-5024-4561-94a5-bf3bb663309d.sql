
-- Table to persist stress readings from S3 polling
CREATE TABLE public.stress_readings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  stress numeric(4,3) NOT NULL CHECK (stress >= 0 AND stress <= 1),
  recorded_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_stress_readings_user_day ON public.stress_readings (user_id, recorded_at DESC);

ALTER TABLE public.stress_readings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own readings"
  ON public.stress_readings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own readings"
  ON public.stress_readings FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Friends can view stress readings"
  ON public.stress_readings FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM friend_connections
      WHERE status = 'accepted'
        AND (
          (requester_id = auth.uid() AND addressee_id = stress_readings.user_id)
          OR (addressee_id = auth.uid() AND requester_id = stress_readings.user_id)
        )
    )
  );

-- Enable realtime for stress_readings
ALTER PUBLICATION supabase_realtime ADD TABLE public.stress_readings;
