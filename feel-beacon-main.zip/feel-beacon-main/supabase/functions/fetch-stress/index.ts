import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const STRESS_URL =
  "https://mindful-makers-dec-20-25.s3.us-east-2.amazonaws.com/stress_reading.txt";

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const response = await fetch(STRESS_URL, { headers: { "Cache-Control": "no-cache" } });
    if (!response.ok) {
      return new Response(
        JSON.stringify({ error: `S3 fetch failed: ${response.status}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const text = (await response.text()).trim();
    // S3 file may contain "timestamp value" format, e.g. "2026-02-14T17:49:00 0.15"
    const parts = text.split(/\s+/);
    const value = parseFloat(parts[parts.length - 1]);

    if (isNaN(value)) {
      return new Response(
        JSON.stringify({ stress: null, raw: text, message: "No valid reading" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const stress = Math.max(0, Math.min(1, value > 1 ? value / 100 : value));

    return new Response(
      JSON.stringify({ stress, raw: text, fetched_at: new Date().toISOString() }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("fetch-stress error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
