import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { stress, recentSongs, intention } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const songContext = recentSongs?.length > 0
      ? `They've recently been listening to: ${recentSongs.map((s: any) => `"${s.title}" (${s.genre})`).join(", ")}.`
      : "They haven't logged any music/sounds recently.";

    const intentionContext = intention
      ? `They are currently focused on: "${intention}".`
      : "";

    const systemPrompt = `You are a calming wellness companion that recommends music, sounds, and ambient audio based on a person's stress level and context. Focus on GENRES, THEMES, and SOUND TYPES rather than specific artists.

Your recommendations should be practical — suggest genres (lo-fi, ambient, classical), sound types (rain, birdsong, white noise), and themes (meditative, energizing, grounding). Adapt your tone:
- Low stress (0-0.3): Encourage maintaining the calm, suggest focus-enhancing sounds
- Medium stress (0.3-0.6): Suggest transitional genres to help ease tension
- High stress (0.6-1.0): Recommend calming, grounding sounds — nature, ambient, slow tempo

Always return a JSON object with these fields:
- "mood": A 1-2 word description of the detected mood (e.g. "Tense", "Calm", "Anxious")
- "moodEmoji": A single emoji representing the mood
- "recommendation": A brief 1-2 sentence recommendation
- "suggestions": An array of 3 objects, each with "title" (sound/genre name), "artist" (genre or theme category like "Ambient", "Lo-fi", "Nature Sounds"), and "why" (brief reason)
- "ambientSuggestion": A short ambient sound description to play (e.g. "gentle rain", "ocean waves")

Only return valid JSON, no markdown or extra text.`;

    const userPrompt = `Current stress level: ${stress ?? "unknown"} (scale 0-1, where 1 is extremely stressed). ${songContext} ${intentionContext} What sounds/music would help right now?`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI analysis failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";

    // Parse JSON from response (may be wrapped in markdown)
    const jsonStr = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

    try {
      const parsed = JSON.parse(jsonStr);
      return new Response(JSON.stringify(parsed), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } catch {
      return new Response(JSON.stringify({ recommendation: content, mood: "Unknown", moodEmoji: "🎵", suggestions: [], ambientSuggestion: null }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  } catch (e) {
    console.error("stress-sound-sync error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
