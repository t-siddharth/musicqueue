export type EmotionType = 'happy' | 'sad' | 'angry' | 'anxious' | 'calm' | 'excited';

export interface EmotionData {
  emotion: EmotionType;
  intensity: number;
  emoji: string;
  label: string;
}

export const EMOTION_CONFIG: Record<EmotionType, { emoji: string; label: string }> = {
  happy: { emoji: '😊', label: 'Happy' },
  sad: { emoji: '😢', label: 'Sad' },
  angry: { emoji: '😠', label: 'Angry' },
  anxious: { emoji: '😰', label: 'Anxious' },
  calm: { emoji: '😌', label: 'Calm' },
  excited: { emoji: '🤩', label: 'Excited' },
};

export function generateMockEmotions(): EmotionData[] {
  const emotions: EmotionType[] = ['happy', 'sad', 'angry', 'anxious', 'calm', 'excited'];
  // Create a realistic distribution — one dominant emotion
  const dominant = emotions[Math.floor(Math.random() * emotions.length)];
  
  return emotions.map(emotion => ({
    emotion,
    intensity: emotion === dominant
      ? 60 + Math.floor(Math.random() * 35)
      : 5 + Math.floor(Math.random() * 45),
    ...EMOTION_CONFIG[emotion],
  }));
}

export function getDominantEmotion(emotions: EmotionData[]): EmotionData {
  return emotions.reduce((max, e) => e.intensity > max.intensity ? e : max, emotions[0]);
}

export function getMoodScore(emotions: EmotionData[]): number {
  const weights: Record<EmotionType, number> = {
    happy: 1, excited: 0.8, calm: 0.6, anxious: -0.4, sad: -0.7, angry: -0.9,
  };
  const totalIntensity = emotions.reduce((sum, e) => sum + e.intensity, 0);
  if (totalIntensity === 0) return 50;
  const weighted = emotions.reduce((sum, e) => sum + e.intensity * weights[e.emotion], 0);
  return Math.round(50 + (weighted / totalIntensity) * 50);
}
