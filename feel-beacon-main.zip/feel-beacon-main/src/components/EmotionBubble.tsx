import { EmotionData, EmotionType } from '@/lib/mockEmotions';
import { cn } from '@/lib/utils';

const sizeMap = (intensity: number) => {
  const base = 60;
  const scale = base + (intensity / 100) * 60;
  return `${scale}px`;
};

const colorClass: Record<EmotionType, string> = {
  happy: 'bg-emotion-happy/20 border-emotion-happy/40 text-emotion-happy',
  sad: 'bg-emotion-sad/20 border-emotion-sad/40 text-emotion-sad',
  angry: 'bg-emotion-angry/20 border-emotion-angry/40 text-emotion-angry',
  anxious: 'bg-emotion-anxious/20 border-emotion-anxious/40 text-emotion-anxious',
  calm: 'bg-emotion-calm/20 border-emotion-calm/40 text-emotion-calm',
  excited: 'bg-emotion-excited/20 border-emotion-excited/40 text-emotion-excited',
};

export default function EmotionBubble({ emotion, intensity, emoji, label }: EmotionData) {
  const size = sizeMap(intensity);

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className={cn(
          'flex items-center justify-center rounded-full border-2 transition-all duration-700 ease-in-out',
          colorClass[emotion],
          intensity > 60 ? 'animate-pulse-soft' : 'animate-float'
        )}
        style={{ width: size, height: size }}
      >
        <span className="text-2xl" role="img" aria-label={label}>{emoji}</span>
      </div>
      <div className="text-center">
        <p className="text-xs font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{intensity}%</p>
      </div>
    </div>
  );
}
