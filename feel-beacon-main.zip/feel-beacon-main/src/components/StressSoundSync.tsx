import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Headphones, Sparkles, Music, Volume2, Waves } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { MusicLog } from '@/hooks/useMusic';
import { toast } from 'sonner';

interface Suggestion {
  title: string;
  artist: string;
  why: string;
}

interface SyncResult {
  mood: string;
  moodEmoji: string;
  recommendation: string;
  suggestions: Suggestion[];
  ambientSuggestion: string | null;
}

interface Props {
  stress: number | null;
  musicLogs: MusicLog[];
  intention: string | null;
}

export default function StressSoundSync({ stress, musicLogs, intention }: Props) {
  const [result, setResult] = useState<SyncResult | null>(null);
  const [loading, setLoading] = useState(false);

  const analyze = useCallback(async () => {
    setLoading(true);
    try {
      const recentSongs = musicLogs.slice(0, 5).map(l => ({ title: l.title, artist: l.artist }));
      const { data, error } = await supabase.functions.invoke('stress-sound-sync', {
        body: { stress, recentSongs, intention },
      });

      if (error) { toast.error('Failed to analyze'); console.error(error); return; }
      if (data?.error) { toast.error(data.error); return; }
      setResult(data);
    } catch (e) {
      console.error(e);
      toast.error('Analysis failed');
    } finally {
      setLoading(false);
    }
  }, [stress, musicLogs, intention]);

  const stressLabel = stress === null ? 'Unknown'
    : stress > 0.7 ? 'High' : stress > 0.4 ? 'Moderate' : 'Low';

  return (
    <div className="rounded-2xl bg-card p-5 pastel-glow space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-pastel-lavender to-pastel-rose">
            <Headphones className="h-4.5 w-4.5 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold tracking-tight">Sound Sync</h3>
            <p className="text-[10px] text-muted-foreground">AI-powered sound matching</p>
          </div>
        </div>
        {result && (
          <span className="text-lg">{result.moodEmoji}</span>
        )}
      </div>

      {/* Stress state pill */}
      <div className="flex items-center gap-3 rounded-xl bg-muted/40 p-3">
        <div className="text-xl">{result?.moodEmoji ?? '🎧'}</div>
        <div className="flex-1">
          <p className="uber-label">Current Mood</p>
          <p className="text-sm font-medium">
            {stress !== null ? `${(stress * 100).toFixed(0)}% — ${stressLabel}` : 'Waiting for data...'}
          </p>
        </div>
        {result && (
          <span className="tableau-chip bg-primary/10 text-primary">{result.mood}</span>
        )}
      </div>

      <Button
        onClick={analyze}
        disabled={loading}
        className="w-full gap-2 rounded-xl bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-md hover:shadow-lg transition-all duration-300"
        size="sm"
      >
        <Sparkles className="h-3.5 w-3.5" />
        {loading ? 'Analyzing...' : result ? 'Refresh' : 'Get Recommendations'}
      </Button>

      {result && (
        <div className="space-y-3 animate-fade-in">
          <div className="rounded-xl bg-gradient-to-br from-pastel-lavender/40 to-pastel-sky/30 p-4">
            <p className="text-sm leading-relaxed">{result.recommendation}</p>
          </div>

          {result.ambientSuggestion && (
            <div className="flex items-center gap-3 rounded-xl bg-pastel-mint/30 p-3">
              <Waves className="h-4 w-4 text-emotion-calm shrink-0" />
              <div>
                <p className="uber-label">Ambient Sound</p>
                <p className="text-sm font-medium">{result.ambientSuggestion}</p>
              </div>
            </div>
          )}

          {result.suggestions.length > 0 && (
            <div className="space-y-2">
              <p className="uber-label">Suggested Sounds</p>
              {result.suggestions.map((s, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 rounded-xl bg-muted/30 p-3 pastel-glow-hover cursor-pointer animate-fade-in"
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-pastel-lavender/60 to-pastel-rose/40">
                    {i === 0 ? <Music className="h-4 w-4 text-primary" /> : <Volume2 className="h-4 w-4 text-primary" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{s.title}</p>
                    <span className="tableau-chip bg-pastel-mint/40 text-foreground/70 text-[9px] px-2 py-0.5 mt-0.5 inline-block">{s.artist}</span>
                    <p className="text-[10px] text-muted-foreground/70 mt-0.5 italic">{s.why}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
