import { TrendingUp, TrendingDown, Activity, BarChart3, Zap } from 'lucide-react';
import { StressReading } from '@/hooks/useLiveStress';

interface Props {
  currentStress: number | null;
  dailyAverage: number | null;
  stressHistory: StressReading[];
}

export default function AnalyticsPanel({ currentStress, dailyAverage, stressHistory }: Props) {
  const current = currentStress !== null ? Math.min(1, Math.max(0, currentStress)) : null;
  const avg = dailyAverage !== null ? Math.min(1, Math.max(0, dailyAverage)) : null;

  // Calculate change from previous reading
  const prevReading = stressHistory.length >= 2 ? stressHistory[stressHistory.length - 2].stress : null;
  const change = current !== null && prevReading !== null ? current - prevReading : null;

  // Peak stress today
  const peak = stressHistory.length > 0
    ? Math.min(1, Math.max(0, Math.max(...stressHistory.map(r => r.stress))))
    : current ?? 0;

  // Total sessions (unique 25-min windows)
  const sessionCount = stressHistory.length;

  const metrics = [
    {
      label: 'Current Stress',
      value: current !== null ? `${(current * 100).toFixed(1)}%` : '—',
      sub: change !== null
        ? `${change >= 0 ? '↑' : '↓'} ${Math.abs(change * 100).toFixed(1)}%`
        : null,
      icon: Activity,
      bg: 'bg-gradient-to-br from-pastel-mint/50 to-pastel-sky/30',
      chipColor: current !== null && current > 0.7
        ? 'bg-destructive/10 text-destructive'
        : current !== null && current > 0.4
        ? 'bg-emotion-anxious/15 text-emotion-anxious'
        : 'bg-emotion-calm/15 text-emotion-calm',
      subColor: change !== null && change >= 0 ? 'text-destructive' : 'text-emotion-calm',
    },
    {
      label: 'Average Stress',
      value: avg !== null ? `${(avg * 100).toFixed(1)}%` : '—',
      sub: null,
      icon: TrendingDown,
      bg: 'bg-gradient-to-br from-pastel-sky/50 to-pastel-mint/30',
      chipColor: avg !== null && avg > 0.7
        ? 'bg-destructive/10 text-destructive'
        : avg !== null && avg > 0.4
        ? 'bg-emotion-anxious/15 text-emotion-anxious'
        : 'bg-emotion-calm/15 text-emotion-calm',
      subColor: '',
    },
    {
      label: 'Peak Stress',
      value: `${(peak * 100).toFixed(1)}%`,
      sub: null,
      icon: BarChart3,
      bg: 'bg-gradient-to-br from-pastel-peach/50 to-pastel-lemon/30',
      chipColor: peak > 0.7
        ? 'bg-destructive/10 text-destructive'
        : peak > 0.4
        ? 'bg-emotion-anxious/15 text-emotion-anxious'
        : 'bg-emotion-calm/15 text-emotion-calm',
      subColor: '',
    },
    {
      label: 'Total Sessions',
      value: String(sessionCount),
      sub: null,
      icon: Zap,
      bg: 'bg-gradient-to-br from-pastel-lavender/50 to-pastel-sky/30',
      chipColor: 'bg-primary/10 text-primary',
      subColor: '',
    },
  ];

  return (
    <div className="grid gap-3 grid-cols-2 sm:grid-cols-4">
      {metrics.map((m, i) => (
        <div
          key={m.label}
          className={`relative overflow-hidden rounded-2xl ${m.bg} p-4 pastel-glow pastel-glow-hover animate-fade-in`}
          style={{ animationDelay: `${i * 80}ms` }}
        >
          <div className="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-card/10" />
          <div className="relative space-y-2">
            <div className="flex items-center gap-1.5">
              <m.icon className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="uber-label">{m.label}</span>
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="uber-metric text-xl">{m.value}</span>
              {m.sub && (
                <span className={`text-xs font-medium ${m.subColor}`}>{m.sub}</span>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
