import { EmotionData, getDominantEmotion, getMoodScore } from '@/lib/mockEmotions';

interface Props {
  emotions: EmotionData[];
}

export default function MoodScore({ emotions }: Props) {
  const dominant = getDominantEmotion(emotions);
  const score = getMoodScore(emotions);
  
  const scoreColor = score >= 70 ? 'text-emotion-happy' : score >= 45 ? 'text-emotion-calm' : 'text-emotion-sad';

  return (
    <div className="flex items-center gap-6">
      <div className="flex flex-col items-center">
        <span className="text-5xl">{dominant.emoji}</span>
        <p className="mt-1 text-sm font-medium text-foreground">{dominant.label}</p>
        <p className="text-xs text-muted-foreground">Dominant</p>
      </div>
      <div className="flex flex-col">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">Mood Score</p>
        <p className={`font-serif text-4xl font-bold ${scoreColor}`}>{score}</p>
        <p className="text-xs text-muted-foreground">out of 100</p>
      </div>
    </div>
  );
}
