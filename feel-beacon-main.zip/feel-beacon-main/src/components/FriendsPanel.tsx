import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Friend } from '@/hooks/useFriends';
import { Users, UserPlus, Check, X, Eye, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  acceptedFriends: Friend[];
  pendingRequests: Friend[];
  sentRequests: Friend[];
  onSendRequest: (email: string) => Promise<{ error: string | null }>;
  onAccept: (id: string) => Promise<void>;
  onDecline: (id: string) => Promise<void>;
  onSelectFriend: (userId: string) => void;
  selectedFriendId?: string;
}

export default function FriendsPanel({
  acceptedFriends, pendingRequests, sentRequests,
  onSendRequest, onAccept, onDecline, onSelectFriend, selectedFriendId,
}: Props) {
  const [search, setSearch] = useState('');
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!search.trim()) return;
    setSending(true);
    const { error } = await onSendRequest(search.trim());
    if (error) toast.error(error);
    else { toast.success('Friend request sent!'); setSearch(''); }
    setSending(false);
  };

  const avatarColors = [
    'from-pastel-lavender to-pastel-rose',
    'from-pastel-mint to-pastel-sky',
    'from-pastel-peach to-pastel-lemon',
    'from-pastel-sky to-pastel-lavender',
    'from-pastel-rose to-pastel-peach',
  ];

  return (
    <div className="rounded-2xl bg-card p-5 pastel-glow space-y-4">
      <div className="flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-pastel-sky to-pastel-mint">
          <Users className="h-4 w-4 text-foreground" />
        </div>
        <div>
          <h3 className="text-sm font-semibold tracking-tight">Friends</h3>
          <p className="text-[10px] text-muted-foreground">{acceptedFriends.length} connected</p>
        </div>
      </div>

      {/* Add friend */}
      <div className="flex gap-2">
        <Input
          placeholder="Search by name..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="flex-1 rounded-xl border-border/50 bg-muted/30 text-sm"
          onKeyDown={e => e.key === 'Enter' && handleSend()}
        />
        <Button size="sm" onClick={handleSend} disabled={sending} className="rounded-xl gap-1">
          <UserPlus className="h-3.5 w-3.5" />
        </Button>
      </div>

      {/* Pending requests */}
      {pendingRequests.length > 0 && (
        <div className="space-y-1.5">
          <p className="uber-label">Incoming</p>
          {pendingRequests.map(f => (
            <div key={f.id} className="flex items-center justify-between rounded-xl bg-pastel-peach/30 p-2.5">
              <span className="text-sm font-medium">{f.displayName}</span>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg hover:bg-emotion-calm/20" onClick={() => onAccept(f.id)}>
                  <Check className="h-3.5 w-3.5 text-emotion-calm" />
                </Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg hover:bg-destructive/10" onClick={() => onDecline(f.id)}>
                  <X className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Sent requests */}
      {sentRequests.length > 0 && (
        <div className="space-y-1.5">
          <p className="uber-label">Sent</p>
          {sentRequests.map(f => (
            <div key={f.id} className="flex items-center justify-between rounded-xl bg-muted/30 p-2.5">
              <span className="text-sm">{f.displayName}</span>
              <span className="tableau-chip bg-muted text-muted-foreground text-[10px]">Pending</span>
            </div>
          ))}
        </div>
      )}

      {/* Accepted friends */}
      <div className="space-y-1.5">
        <p className="uber-label">Connected</p>
        {acceptedFriends.length === 0 ? (
          <div className="flex flex-col items-center gap-1 py-4">
            <span className="text-lg">👋</span>
            <p className="text-xs text-muted-foreground">No friends yet</p>
          </div>
        ) : (
          acceptedFriends.map((f, i) => (
            <button
              key={f.id}
              onClick={() => onSelectFriend(f.userId)}
              className={`flex w-full items-center gap-3 rounded-xl p-2.5 transition-all duration-200 ${
                selectedFriendId === f.userId
                  ? 'bg-primary/8 ring-1 ring-primary/25 shadow-sm'
                  : 'hover:bg-muted/40'
              }`}
            >
              <div className={`flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br ${avatarColors[i % avatarColors.length]} text-xs font-semibold`}>
                {f.displayName.charAt(0).toUpperCase()}
              </div>
              <span className="text-sm font-medium flex-1 text-left">{f.displayName}</span>
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          ))
        )}
      </div>
    </div>
  );
}
