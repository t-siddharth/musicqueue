import { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Target, Check, X, Zap } from 'lucide-react';
import { toast } from 'sonner';

export default function ManualIntention() {
  const [intention, setIntention] = useState('');
  const [activeIntention, setActiveIntention] = useState<string | null>(null);
  const [startedAt, setStartedAt] = useState<Date | null>(null);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('nsd_intention');
    const savedAt = localStorage.getItem('nsd_intention_at');
    if (saved) {
      setActiveIntention(saved);
      setStartedAt(savedAt ? new Date(savedAt) : new Date());
    }
  }, []);

  const setFocus = useCallback(() => {
    if (!intention.trim()) return;
    const now = new Date();
    setActiveIntention(intention.trim());
    setStartedAt(now);
    localStorage.setItem('nsd_intention', intention.trim());
    localStorage.setItem('nsd_intention_at', now.toISOString());
    setIntention('');
    setEditing(false);
    toast.success('Focus intention set');
  }, [intention]);

  const clearFocus = useCallback(() => {
    setActiveIntention(null);
    setStartedAt(null);
    localStorage.removeItem('nsd_intention');
    localStorage.removeItem('nsd_intention_at');
    toast('Focus cleared');
  }, []);

  const elapsed = startedAt
    ? Math.floor((Date.now() - startedAt.getTime()) / 60000)
    : 0;

  return (
    <div className="rounded-2xl bg-card p-5 pastel-glow space-y-3">
      <div className="flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-pastel-lemon to-pastel-peach">
          <Target className="h-4 w-4 text-foreground" />
        </div>
        <div>
          <h3 className="text-sm font-semibold tracking-tight">Focus Mode</h3>
          <p className="text-[10px] text-muted-foreground">Set your current intention</p>
        </div>
      </div>

      {activeIntention && !editing ? (
        <div className="space-y-3 animate-fade-in">
          <div className="rounded-xl bg-gradient-to-br from-pastel-lemon/30 to-pastel-mint/20 p-4">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Zap className="h-3 w-3 text-emotion-happy" />
              <p className="uber-label">Active Focus</p>
            </div>
            <p className="text-sm font-medium">{activeIntention}</p>
            <p className="text-[10px] text-muted-foreground mt-2">
              {elapsed < 1 ? 'Just started' : `${elapsed}m focused`}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1 rounded-xl text-xs" onClick={() => setEditing(true)}>
              Change
            </Button>
            <Button variant="ghost" size="sm" className="rounded-xl text-xs text-muted-foreground" onClick={clearFocus}>
              <X className="h-3 w-3 mr-1" />
              Clear
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-2 animate-fade-in">
          <Input
            placeholder="What are you focusing on?"
            value={intention}
            onChange={e => setIntention(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && setFocus()}
            className="rounded-xl border-border/50 bg-muted/30 text-sm"
          />
          <Button
            onClick={setFocus}
            disabled={!intention.trim()}
            className="w-full gap-2 rounded-xl text-xs"
            size="sm"
          >
            <Check className="h-3 w-3" />
            Set Focus
          </Button>
          {editing && (
            <Button variant="ghost" size="sm" className="w-full rounded-xl text-xs" onClick={() => setEditing(false)}>
              Cancel
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
