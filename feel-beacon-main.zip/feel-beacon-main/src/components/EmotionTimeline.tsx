import { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { StressReading } from '@/hooks/useLiveStress';
import { format } from 'date-fns';

interface Props {
  stressHistory: StressReading[];
  currentStress: number | null;
  dailyAverage: number | null;
}

export default function EmotionTimeline({ stressHistory, currentStress, dailyAverage }: Props) {
  // Data is in 0-1 scale
  const chartData = useMemo(() => {
    if (stressHistory.length === 0 && currentStress === null) return [];
    if (stressHistory.length === 0 && currentStress !== null) {
      return [{ time: Date.now(), stress: currentStress }];
    }
    return stressHistory;
  }, [stressHistory, currentStress]);

  const formatTick = (value: number) => format(new Date(value), 'HH:mm');

  // Domain: min(16:00 today, earliest data) → now
  const domainStart = useMemo(() => {
    const four = new Date();
    four.setHours(16, 0, 0, 0);
    const fourTs = four.getTime();
    const earliest = chartData.length > 0 ? chartData[0].time : Date.now();
    return Math.min(fourTs, earliest);
  }, [chartData]);
  const domainEnd = Date.now();

  // Generate 25-min interval ticks across domain
  const intervalTicks = useMemo(() => {
    const ticks: number[] = [];
    const start = new Date(domainStart);
    start.setMinutes(Math.floor(start.getMinutes() / 25) * 25, 0, 0);
    let t = start.getTime();
    while (t <= domainEnd + 25 * 60 * 1000) {
      ticks.push(t);
      t += 25 * 60 * 1000;
    }
    return ticks;
  }, [domainStart, domainEnd]);

  return (
    <div className="rounded-2xl bg-card p-5 pastel-glow">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="apple-section-title">Stress Timeline — Today</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {chartData.length > 1
              ? `${chartData.length} readings · 25min intervals`
              : 'Building timeline as readings come in...'}
          </p>
        </div>
        {currentStress !== null && (
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-emotion-calm animate-pulse-soft" />
            <span className="text-xs font-medium text-muted-foreground">Live</span>
          </div>
        )}
      </div>

      {chartData.length === 0 ? (
        <div className="flex h-52 flex-col items-center justify-center gap-2">
          <div className="h-12 w-12 rounded-2xl bg-pastel-mint/50 flex items-center justify-center">
            <span className="text-xl">📡</span>
          </div>
          <p className="text-sm text-muted-foreground">Waiting for stress data...</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 20 }}>
            <defs>
              <linearGradient id="liveStressGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(175, 55%, 42%)" stopOpacity={0.3} />
                <stop offset="50%" stopColor="hsl(200, 70%, 50%)" stopOpacity={0.15} />
                <stop offset="100%" stopColor="hsl(175, 55%, 42%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.4} />
            <XAxis
              dataKey="time"
              type="number"
              domain={[domainStart, domainEnd]}
              allowDataOverflow
              tickFormatter={formatTick}
              ticks={intervalTicks.length > 0 ? intervalTicks : undefined}
              tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
              stroke="hsl(var(--border))"
              strokeWidth={1}
              tickLine={{ stroke: 'hsl(var(--border))', strokeWidth: 1 }}
              tickMargin={8}
              label={{ value: 'Time', position: 'insideBottom', offset: -12, fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
            />
            <YAxis
              domain={[0, 1]}
              ticks={[0, 0.2, 0.4, 0.6, 0.8, 1.0]}
              tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
              stroke="hsl(var(--border))"
              strokeWidth={1}
              tickLine={{ stroke: 'hsl(var(--border))', strokeWidth: 1 }}
              tickMargin={4}
              width={40}
              tickFormatter={(v: number) => v.toFixed(1)}
              label={{ value: 'Stress Level', angle: -90, position: 'insideLeft', offset: 10, fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
            />
            <Tooltip
              contentStyle={{
                background: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '12px',
                fontSize: 12,
                padding: '8px 12px',
                boxShadow: '0 8px 24px -4px hsl(var(--primary) / 0.1)',
              }}
              labelFormatter={(v) => {
                const d = new Date(v);
                return isNaN(d.getTime()) ? '' : format(d, 'HH:mm:ss');
              }}
              formatter={(value: number) => [value.toFixed(2), 'Stress']}
            />
            <Area
              type="monotone"
              dataKey="stress"
              stroke="hsl(175, 55%, 42%)"
              strokeWidth={2.5}
              fill="url(#liveStressGradient)"
              dot={chartData.length <= 20}
              activeDot={{ r: 5, fill: 'hsl(175, 55%, 42%)', stroke: 'hsl(var(--card))', strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
