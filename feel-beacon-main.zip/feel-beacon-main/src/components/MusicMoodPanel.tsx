import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MusicLog } from '@/hooks/useMusic';
import { Music, Plus, Clock, Sparkles, Brain, Disc3 } from 'lucide-react';
import { format } from 'date-fns';

interface Props {
  musicLogs: MusicLog[];
  onAddSong: (title: string, artist: string) => Promise<void>;
  loading: boolean;
  aiInsight: string | null;
  moodTags: Record<string, string>;
  onAnalyze: () => Promise<void>;
  analyzing: boolean;
}

export default function MusicMoodPanel({ musicLogs, onAddSong, loading, aiInsight, moodTags, onAnalyze, analyzing }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleAdd = async () => {
    if (!title.trim() || !genre.trim()) return;
    setSubmitting(true);
    await onAddSong(title.trim(), genre.trim());
    setTitle(''); setGenre(''); setShowForm(false); setSubmitting(false);
  };

  const themes = getMusicThemes(musicLogs);

  const trackColors = [
    'from-pastel-lavender/60 to-pastel-rose/40',
    'from-pastel-mint/60 to-pastel-sky/40',
    'from-pastel-peach/60 to-pastel-lemon/40',
    'from-pastel-sky/60 to-pastel-lavender/40',
    'from-pastel-rose/60 to-pastel-peach/40',
  ];

  return (
    <div className="rounded-2xl bg-card p-5 pastel-glow space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-pastel-rose to-pastel-lavender">
            <Music className="h-4 w-4 text-foreground" />
          </div>
          <div>
            <h3 className="text-sm font-semibold tracking-tight">Sounds & Genres</h3>
            <p className="text-[10px] text-muted-foreground">{musicLogs.length} logged</p>
          </div>
        </div>
        <div className="flex gap-1">
          {musicLogs.length >= 2 && (
            <Button variant="ghost" size="sm" onClick={onAnalyze} disabled={analyzing} className="rounded-xl gap-1 text-xs h-8">
              <Sparkles className="h-3 w-3" />
              {analyzing ? '...' : 'AI'}
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => setShowForm(!showForm)} className="rounded-xl gap-1 text-xs h-8">
            <Plus className="h-3 w-3" />
            Log
          </Button>
        </div>
      </div>

      {showForm && (
        <div className="flex gap-2 animate-fade-in">
          <Input placeholder="Sound / Song" value={title} onChange={e => setTitle(e.target.value)} className="flex-1 rounded-xl text-sm bg-muted/30" />
          <Input placeholder="Genre / Theme" value={genre} onChange={e => setGenre(e.target.value)} className="flex-1 rounded-xl text-sm bg-muted/30" />
          <Button size="sm" onClick={handleAdd} disabled={submitting} className="rounded-xl">Add</Button>
        </div>
      )}

      {/* AI Insight */}
      {aiInsight && (
        <div className="rounded-xl bg-gradient-to-br from-pastel-lavender/40 to-pastel-sky/30 p-4 animate-fade-in">
          <div className="flex items-center gap-1.5 mb-2">
            <Brain className="h-3.5 w-3.5 text-primary" />
            <p className="uber-label">AI Insight</p>
          </div>
          <p className="text-sm leading-relaxed">{aiInsight}</p>
        </div>
      )}

      {/* Themes */}
      {themes.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {themes.map((theme, i) => (
            <span key={i} className="tableau-chip bg-pastel-lavender/50 text-accent-foreground text-[10px]">
              {theme}
            </span>
          ))}
        </div>
      )}

      {/* Sound Trail */}
      <div className="space-y-1.5">
        <p className="uber-label">Sound Trail</p>
        {musicLogs.length === 0 ? (
          <div className="flex flex-col items-center gap-1 py-4">
            <span className="text-lg">🎵</span>
            <p className="text-xs text-muted-foreground">No sounds logged yet</p>
          </div>
        ) : (
          <div className="space-y-1.5 max-h-72 overflow-y-auto">
            {musicLogs.slice(0, 12).map((log, i) => {
              const moodTag = moodTags[`${log.title}-${log.artist}`];
              return (
                <div
                  key={log.id}
                  className="flex items-center gap-3 rounded-xl p-2.5 hover:bg-muted/30 transition-all duration-200 animate-fade-in cursor-pointer"
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${trackColors[i % trackColors.length]}`}>
                    <Disc3 className="h-4 w-4 text-foreground/70" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{log.title}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{log.artist}</p>
                  </div>
                  <div className="flex flex-col items-end gap-0.5 shrink-0">
                    <span className="text-[10px] text-muted-foreground">
                      {format(new Date(log.logged_at), 'HH:mm')}
                    </span>
                    {moodTag && (
                      <span className="tableau-chip bg-primary/8 text-primary text-[9px] px-2 py-0.5">
                        {moodTag}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function getMusicThemes(logs: MusicLog[]): string[] {
  if (logs.length === 0) return [];
  const genres = new Set(logs.map(l => l.artist));
  const themes: string[] = [];
  // Show unique genres as theme chips
  genres.forEach(g => themes.push(g));
  if (logs.length >= 5) themes.push('Active listener');
  return themes.slice(0, 6);
}
