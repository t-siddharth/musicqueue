import { Activity, Wifi, WifiOff, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';

interface Props {
  stress: number | null;
  dailyAverage: number | null;
  loading: boolean;
  error: string | null;
  lastFetched: string | null;
  onRefresh: () => void;
  readingCount: number;
}

export default function LiveStressCard({ stress, dailyAverage, loading, error, lastFetched, onRefresh, readingCount }: Props) {
  const avg = dailyAverage;
  const hasReading = avg !== null;
  // Clamp to 0-1 range then display as percentage
  const clampedAvg = hasReading ? Math.min(1, Math.max(0, avg)) : 0;
  const avgPercent = hasReading ? Math.round(clampedAvg * 100) : 0;
  const stressLabel = !hasReading ? 'Waiting...'
    : avg > 0.7 ? 'High Stress' : avg > 0.4 ? 'Moderate' : 'Relaxed';

  const ringGradient = !hasReading ? 'from-muted to-muted'
    : avg > 0.7 ? 'from-destructive via-emotion-angry to-emotion-anxious'
    : avg > 0.4 ? 'from-emotion-anxious via-emotion-happy to-primary'
    : 'from-emotion-calm via-pastel-mint to-primary';

  const bgTone = !hasReading ? 'bg-muted/30'
    : avg > 0.7 ? 'bg-gradient-to-br from-pastel-rose/40 to-pastel-peach/20'
    : avg > 0.4 ? 'bg-gradient-to-br from-pastel-peach/40 to-pastel-lemon/20'
    : 'bg-gradient-to-br from-pastel-mint/40 to-pastel-sky/20';

  return (
    <div className={`relative overflow-hidden rounded-2xl ${bgTone} p-5 pastel-glow pastel-glow-hover`}>
      <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-gradient-to-br from-primary/5 to-transparent" />

      <div className="relative flex items-start justify-between">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className={`flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br ${ringGradient}`}>
              <Activity className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="uber-label">Daily Avg Stress</span>
            {stress !== null ? (
              <Wifi className="h-3 w-3 text-emotion-calm" />
            ) : (
              <WifiOff className="h-3 w-3 text-muted-foreground" />
            )}
          </div>

          {loading ? (
            <div className="h-10 w-24 rounded-lg bg-muted/50 animate-shimmer bg-gradient-to-r from-muted/50 via-muted/80 to-muted/50 bg-[length:200%_100%]" />
          ) : hasReading ? (
            <div className="flex items-baseline gap-2">
              <span className="uber-metric">{avgPercent}%</span>
            </div>
          ) : (
            <p className="text-sm font-medium text-muted-foreground">No reading</p>
          )}

          <div className="flex items-center gap-2">
            <span className={`tableau-chip ${
              !hasReading ? 'bg-muted text-muted-foreground'
                : avg! > 0.7 ? 'bg-destructive/10 text-destructive'
                : avg! > 0.4 ? 'bg-emotion-anxious/15 text-emotion-anxious'
                : 'bg-emotion-calm/15 text-emotion-calm'
            }`}>
              {stressLabel}
            </span>
            {readingCount > 0 && (
              <span className="tableau-chip bg-primary/10 text-primary text-[10px]">
                {readingCount} readings today
              </span>
            )}
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 rounded-xl hover:bg-card/60"
          onClick={onRefresh}
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {hasReading && (
        <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-card/50">
          <div
            className={`h-full rounded-full bg-gradient-to-r ${ringGradient} transition-all duration-1000 ease-out`}
            style={{ width: `${avgPercent}%` }}
          />
        </div>
      )}

      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}

      {lastFetched && (
        <p className="mt-3 text-[10px] text-muted-foreground/70">
          Updated {format(new Date(lastFetched), 'HH:mm:ss')} · Polling every 5s
        </p>
      )}
    </div>
  );
}
