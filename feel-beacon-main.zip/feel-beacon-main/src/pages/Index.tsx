import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useEmotions } from '@/hooks/useEmotions';
import { useMusic } from '@/hooks/useMusic';
import { useFriends } from '@/hooks/useFriends';
import { useLiveStress } from '@/hooks/useLiveStress';
import DashboardHeader from '@/components/DashboardHeader';
import EmotionTimeline from '@/components/EmotionTimeline';
import MusicMoodPanel from '@/components/MusicMoodPanel';
import AnalyticsPanel from '@/components/AnalyticsPanel';
import LiveStressCard from '@/components/LiveStressCard';
import ManualIntention from '@/components/ManualIntention';
import FriendsPanel from '@/components/FriendsPanel';
import StressSoundSync from '@/components/StressSoundSync';
import { Button } from '@/components/ui/button';
import { Sparkles, RefreshCw } from 'lucide-react';

export default function Index() {
  const { user, loading: authLoading } = useAuth();
  const [selectedFriendId, setSelectedFriendId] = useState<string | undefined>();

  const viewUserId = selectedFriendId || undefined;
  const { emotions, history, timeFilter, setTimeFilter, loading: emotionsLoading, simulateEmotions } = useEmotions(viewUserId);
  const { musicLogs, loading: musicLoading, addSong, aiInsight, moodTags, analyzeMood, analyzingMood } = useMusic(viewUserId);
  const { acceptedFriends, pendingRequests, sentRequests, sendRequest, acceptRequest, declineRequest } = useFriends();

  // Live stress — pass friendUserId to load their DB history instead of polling S3
  const {
    stress: liveStress, loading: liveLoading, error: liveError,
    lastFetched, history: stressHistory, dailyAverage,
    refetch: refetchStress
  } = useLiveStress(selectedFriendId);

  const activeIntention = typeof window !== 'undefined' ? localStorage.getItem('nsd_intention') : null;

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="animate-breathe flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-pastel-lavender to-pastel-rose">
          <Sparkles className="h-7 w-7 text-primary" />
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/auth" replace />;

  const isViewingSelf = !selectedFriendId;
  const viewingFriend = acceptedFriends.find(f => f.userId === selectedFriendId);

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <main className="mx-auto max-w-6xl px-5 py-6 sm:px-8">
        <div className="space-y-6">
          {viewingFriend && (
            <div className="flex items-center justify-between rounded-2xl bg-pastel-sky/30 border border-pastel-sky/50 p-3.5 animate-fade-in">
              <p className="text-sm">
                Viewing <span className="font-semibold text-primary">{viewingFriend.displayName}</span>'s stress data
              </p>
              <Button variant="ghost" size="sm" onClick={() => setSelectedFriendId(undefined)} className="rounded-xl text-xs">
                Back to my data
              </Button>
            </div>
          )}

          {/* Section header */}
          <div className="flex items-center justify-between animate-fade-in">
            <div>
              <h2 className="apple-section-title">
                {viewingFriend ? `${viewingFriend.displayName}'s Stress` : 'Stress Overview'}
              </h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isViewingSelf ? 'Real-time monitoring & daily average' : "Friend's daily stress data"}
              </p>
            </div>
            {isViewingSelf && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => simulateEmotions(musicLogs.length, moodTags)}
                className="gap-2 rounded-xl text-xs"
              >
                <RefreshCw className="h-3 w-3" />
                Simulate
              </Button>
            )}
          </div>

          {/* Stress metrics row */}
          <div className="grid gap-4 sm:grid-cols-2 animate-slide-up" style={{ animationDelay: '100ms' }}>
            <LiveStressCard
              stress={liveStress}
              dailyAverage={dailyAverage}
              loading={liveLoading}
              error={liveError}
              lastFetched={lastFetched}
              onRefresh={refetchStress}
              readingCount={stressHistory.length}
            />
            <AnalyticsPanel currentStress={liveStress} dailyAverage={dailyAverage} stressHistory={stressHistory} />
          </div>

          {/* Main content grid */}
          <div className="grid gap-5 lg:grid-cols-3 animate-slide-up" style={{ animationDelay: '200ms' }}>
            <div className="lg:col-span-2 space-y-5">
              <EmotionTimeline stressHistory={stressHistory} currentStress={liveStress} dailyAverage={dailyAverage} />
              {isViewingSelf && (
                <StressSoundSync stress={liveStress} musicLogs={musicLogs} intention={activeIntention} />
              )}
            </div>

            <div className="space-y-5">
              {isViewingSelf && <ManualIntention />}
              <FriendsPanel
                acceptedFriends={acceptedFriends}
                pendingRequests={pendingRequests}
                sentRequests={sentRequests}
                onSendRequest={sendRequest}
                onAccept={acceptRequest}
                onDecline={declineRequest}
                onSelectFriend={setSelectedFriendId}
                selectedFriendId={selectedFriendId}
              />
              <MusicMoodPanel
                musicLogs={musicLogs}
                onAddSong={addSong}
                loading={musicLoading}
                aiInsight={aiInsight}
                moodTags={moodTags}
                onAnalyze={analyzeMood}
                analyzing={analyzingMood}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
