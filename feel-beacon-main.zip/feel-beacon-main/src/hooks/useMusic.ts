import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface MusicLog {
  id: string;
  title: string;
  artist: string;
  mood_inference: string | null;
  logged_at: string;
  user_id: string;
}

export function useMusic(targetUserId?: string) {
  const { user } = useAuth();
  const [musicLogs, setMusicLogs] = useState<MusicLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [moodTags, setMoodTags] = useState<Record<string, string>>({});
  const [analyzingMood, setAnalyzingMood] = useState(false);

  const userId = targetUserId || user?.id;

  const fetchMusic = useCallback(async () => {
    if (!userId) return;
    const { data, error } = await supabase
      .from('music_logs')
      .select('*')
      .eq('user_id', userId)
      .order('logged_at', { ascending: false })
      .limit(20);

    if (error) console.error('Error fetching music:', error);
    setMusicLogs((data as MusicLog[]) || []);
    setLoading(false);
  }, [userId]);

  // artist field stores genre/theme

  useEffect(() => {
    fetchMusic();
  }, [fetchMusic]);

  const addSong = useCallback(async (title: string, artist: string) => {
    if (!user?.id) return;
    const { error } = await supabase.from('music_logs').insert({
      user_id: user.id,
      title,
      artist,
    });
    if (error) console.error('Error adding song:', error);
    else fetchMusic();
  }, [user?.id, fetchMusic]);

  const analyzeMood = useCallback(async () => {
    if (musicLogs.length < 2) return;
    setAnalyzingMood(true);

    try {
      const songs = musicLogs.slice(0, 10).map(l => ({ title: l.title, artist: l.artist }));

      // Fetch both mood tags and daily insight in parallel
      const [tagsRes, insightRes] = await Promise.all([
        supabase.functions.invoke('music-mood', { body: { songs, type: 'tags' } }),
        supabase.functions.invoke('music-mood', { body: { songs, type: 'daily_insight' } }),
      ]);

      if (insightRes.data?.result) {
        setAiInsight(insightRes.data.result);
      }

      if (tagsRes.data?.result) {
        try {
          // Extract JSON from the response (might be wrapped in markdown)
          const jsonStr = tagsRes.data.result.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
          const parsed = JSON.parse(jsonStr);
          const tags: Record<string, string> = {};
          for (const item of parsed) {
            tags[`${item.title}-${item.artist}`] = item.mood;
          }
          setMoodTags(tags);
        } catch {
          console.error('Failed to parse mood tags');
        }
      }
    } catch (e) {
      console.error('Error analyzing mood:', e);
    } finally {
      setAnalyzingMood(false);
    }
  }, [musicLogs]);

  return { musicLogs, loading, addSong, refetch: fetchMusic, aiInsight, moodTags, analyzeMood, analyzingMood };
}
