import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { EmotionData, EmotionType, EMOTION_CONFIG, generateMockEmotions, getDominantEmotion, getMoodScore } from '@/lib/mockEmotions';

export interface EmotionRecord {
  id: string;
  emotion: EmotionType;
  intensity: number;
  recorded_at: string;
  user_id: string;
}

export type TimeFilter = 'hour' | 'today' | 'week' | 'month';

function getFilterDate(filter: TimeFilter): Date {
  const now = new Date();
  switch (filter) {
    case 'hour': return new Date(now.getTime() - 60 * 60 * 1000);
    case 'today': return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    case 'week': return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    case 'month': return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }
}

export function useEmotions(targetUserId?: string) {
  const { user } = useAuth();
  const [emotions, setEmotions] = useState<EmotionData[]>(generateMockEmotions());
  const [history, setHistory] = useState<EmotionRecord[]>([]);
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('today');
  const [loading, setLoading] = useState(true);

  const userId = targetUserId || user?.id;

  const fetchEmotions = useCallback(async () => {
    if (!userId) return;

    const { data, error } = await supabase
      .from('emotion_records')
      .select('*')
      .eq('user_id', userId)
      .order('recorded_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Error fetching emotions:', error);
      setLoading(false);
      return;
    }

    if (data && data.length > 0) {
      const latestByEmotion = new Map<EmotionType, number>();
      for (const record of data) {
        const emotion = record.emotion as EmotionType;
        if (!latestByEmotion.has(emotion)) {
          latestByEmotion.set(emotion, record.intensity);
        }
      }

      const allEmotions: EmotionType[] = ['happy', 'sad', 'angry', 'anxious', 'calm', 'excited'];
      const aggregated: EmotionData[] = allEmotions.map(emotion => ({
        emotion,
        intensity: latestByEmotion.get(emotion) ?? 0,
        ...EMOTION_CONFIG[emotion],
      }));
      setEmotions(aggregated);
    }
    setLoading(false);
  }, [userId]);

  const fetchHistory = useCallback(async () => {
    if (!userId) return;

    const since = getFilterDate(timeFilter).toISOString();
    const { data, error } = await supabase
      .from('emotion_records')
      .select('*')
      .eq('user_id', userId)
      .gte('recorded_at', since)
      .order('recorded_at', { ascending: true });

    if (error) {
      console.error('Error fetching history:', error);
      return;
    }
    setHistory((data as EmotionRecord[]) || []);
  }, [userId, timeFilter]);

  useEffect(() => {
    if (!userId) return;
    fetchEmotions();
    fetchHistory();

    const channel = supabase
      .channel(`emotions-${userId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'emotion_records',
        filter: `user_id=eq.${userId}`,
      }, (payload) => {
        const newRecord = payload.new as EmotionRecord;
        setEmotions(prev =>
          prev.map(e =>
            e.emotion === newRecord.emotion ? { ...e, intensity: newRecord.intensity } : e
          )
        );
        setHistory(prev => [...prev, newRecord]);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [userId, fetchEmotions, fetchHistory]);

  const simulateEmotions = useCallback(async (musicLogCount?: number, moodTags?: Record<string, string>) => {
    if (!user?.id) return;

    // Base stress influenced by music/sound context
    let baseAnxious = 15 + Math.floor(Math.random() * 30);
    let baseAngry = 10 + Math.floor(Math.random() * 20);

    // Music logs present → listening generally reduces stress
    if (musicLogCount && musicLogCount > 0) {
      const calmingFactor = Math.min(musicLogCount * 3, 25);
      baseAnxious = Math.max(5, baseAnxious - calmingFactor);
      baseAngry = Math.max(3, baseAngry - calmingFactor);
    }

    // AI mood tags influence stress — negative moods raise stress, positive lower it
    if (moodTags && Object.keys(moodTags).length > 0) {
      const tags = Object.values(moodTags).map(t => t.toLowerCase());
      const negativeWords = ['sad', 'angry', 'dark', 'aggressive', 'melancholy', 'tense', 'anxious', 'intense', 'heavy'];
      const positiveWords = ['happy', 'calm', 'upbeat', 'peaceful', 'relaxed', 'joyful', 'chill', 'soothing', 'mellow'];
      
      let moodShift = 0;
      for (const tag of tags) {
        if (negativeWords.some(w => tag.includes(w))) moodShift += 8;
        if (positiveWords.some(w => tag.includes(w))) moodShift -= 8;
      }
      baseAnxious = Math.min(95, Math.max(5, baseAnxious + moodShift));
      baseAngry = Math.min(90, Math.max(3, baseAngry + moodShift * 0.6));
    }

    // Add some natural variance
    const jitter = () => Math.floor(Math.random() * 10) - 5;

    const records = [
      { user_id: user.id, emotion: 'anxious' as EmotionType, intensity: Math.min(100, Math.max(0, baseAnxious + jitter())) },
      { user_id: user.id, emotion: 'angry' as EmotionType, intensity: Math.min(100, Math.max(0, baseAngry + jitter())) },
      // Keep other emotions low/contextual
      { user_id: user.id, emotion: 'calm' as EmotionType, intensity: Math.min(100, Math.max(0, 100 - baseAnxious + jitter())) },
      { user_id: user.id, emotion: 'happy' as EmotionType, intensity: Math.min(100, Math.max(0, 80 - baseAnxious + jitter())) },
      { user_id: user.id, emotion: 'sad' as EmotionType, intensity: Math.min(100, Math.max(0, baseAnxious * 0.3 + jitter())) },
      { user_id: user.id, emotion: 'excited' as EmotionType, intensity: Math.min(100, Math.max(0, 50 - baseAngry + jitter())) },
    ];

    const { error } = await supabase.from('emotion_records').insert(records);
    if (error) console.error('Error inserting emotions:', error);
  }, [user?.id]);

  return {
    emotions,
    history,
    timeFilter,
    setTimeFilter,
    loading,
    simulateEmotions,
    dominant: getDominantEmotion(emotions),
    moodScore: getMoodScore(emotions),
  };
}
