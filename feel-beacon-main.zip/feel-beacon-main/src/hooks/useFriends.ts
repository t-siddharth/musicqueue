import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface Friend {
  id: string;
  userId: string;
  displayName: string;
  avatarUrl: string | null;
  status: 'pending' | 'accepted' | 'declined';
  isRequester: boolean;
}

export function useFriends() {
  const { user } = useAuth();
  const [friends, setFriends] = useState<Friend[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchFriends = useCallback(async () => {
    if (!user?.id) return;

    const { data: connections, error } = await supabase
      .from('friend_connections')
      .select('*')
      .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`);

    if (error) {
      console.error('Error fetching friends:', error);
      setLoading(false);
      return;
    }

    if (!connections || connections.length === 0) {
      setFriends([]);
      setLoading(false);
      return;
    }

    // Get friend user IDs
    const friendUserIds = connections.map(c =>
      c.requester_id === user.id ? c.addressee_id : c.requester_id
    );

    // Fetch profiles
    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('user_id', friendUserIds);

    const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);

    const mapped: Friend[] = connections.map(c => {
      const friendUserId = c.requester_id === user.id ? c.addressee_id : c.requester_id;
      const profile = profileMap.get(friendUserId);
      return {
        id: c.id,
        userId: friendUserId,
        displayName: profile?.display_name || 'Unknown',
        avatarUrl: profile?.avatar_url || null,
        status: c.status as Friend['status'],
        isRequester: c.requester_id === user.id,
      };
    });

    setFriends(mapped);
    setLoading(false);
  }, [user?.id]);

  useEffect(() => {
    fetchFriends();
  }, [fetchFriends]);

  const sendRequest = useCallback(async (email: string) => {
    if (!user?.id) return { error: 'Not logged in' };

    // Find user by email
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, display_name')
      .ilike('display_name', `%${email}%`);

    // Also try matching the email stored in display_name fallback
    if (!profiles || profiles.length === 0) {
      return { error: 'User not found' };
    }

    const target = profiles.find(p => p.user_id !== user.id);
    if (!target) return { error: 'User not found' };

    const { error } = await supabase.from('friend_connections').insert({
      requester_id: user.id,
      addressee_id: target.user_id,
    });

    if (error) {
      if (error.code === '23505') return { error: 'Already connected' };
      return { error: error.message };
    }

    fetchFriends();
    return { error: null };
  }, [user?.id, fetchFriends]);

  const acceptRequest = useCallback(async (connectionId: string) => {
    const { error } = await supabase
      .from('friend_connections')
      .update({ status: 'accepted' as const })
      .eq('id', connectionId);
    if (!error) fetchFriends();
  }, [fetchFriends]);

  const declineRequest = useCallback(async (connectionId: string) => {
    const { error } = await supabase
      .from('friend_connections')
      .update({ status: 'declined' as const })
      .eq('id', connectionId);
    if (!error) fetchFriends();
  }, [fetchFriends]);

  const acceptedFriends = friends.filter(f => f.status === 'accepted');
  const pendingRequests = friends.filter(f => f.status === 'pending' && !f.isRequester);
  const sentRequests = friends.filter(f => f.status === 'pending' && f.isRequester);

  return {
    friends,
    acceptedFriends,
    pendingRequests,
    sentRequests,
    loading,
    sendRequest,
    acceptRequest,
    declineRequest,
    refetch: fetchFriends,
  };
}
