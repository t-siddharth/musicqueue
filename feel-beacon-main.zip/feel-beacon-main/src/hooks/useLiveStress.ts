import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

const STRESS_URL = 'https://mindful-makers-dec-20-25.s3.us-east-2.amazonaws.com/stress_reading.txt';
const POLL_INTERVAL = 5_000;

export interface StressReading {
  time: number;
  stress: number;
}

interface LiveStressState {
  stress: number | null;
  loading: boolean;
  error: string | null;
  lastFetched: string | null;
  history: StressReading[];
  dailyAverage: number | null;
}

export function useLiveStress(friendUserId?: string) {
  const { user } = useAuth();
  const [state, setState] = useState<LiveStressState>({
    stress: null,
    loading: true,
    error: null,
    lastFetched: null,
    history: [],
    dailyAverage: null,
  });
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Generate sample data for today to show a full timeline
  const generateSampleData = useCallback((): StressReading[] => {
    const now = new Date();
    const todayStart = new Date();
    todayStart.setHours(16, 0, 0, 0); // Start from 4 PM
    const readings: StressReading[] = [];
    let t = todayStart.getTime();
    const end = now.getTime();

    // Simulate a realistic stress curve from 4 PM onwards, 25 min intervals (0-1 scale)
    while (t <= end) {
      const hour = new Date(t).getHours();
      let base: number;
      if (hour < 17) base = 0.3 + Math.random() * 0.15;       // late afternoon
      else if (hour < 19) base = 0.45 + Math.random() * 0.2;  // early evening peak
      else if (hour < 21) base = 0.25 + Math.random() * 0.15; // evening calm
      else base = 0.4 + Math.random() * 0.25;                  // late evening

      readings.push({ time: t, stress: parseFloat(base.toFixed(2)) });
      t += 25 * 60 * 1000; // every 25 min
    }
    return readings;
  }, []);

  // Load today's history from DB on mount
  useEffect(() => {
    const targetUserId = friendUserId || user?.id;
    if (!targetUserId) return;

    const loadTodayHistory = async () => {
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from('stress_readings')
        .select('stress, recorded_at')
        .eq('user_id', targetUserId)
        .gte('recorded_at', todayStart.toISOString())
        .order('recorded_at', { ascending: true });

      // Always start with sample data for a full trail, then overlay real readings
      const sample = generateSampleData();
      const dbHistory: StressReading[] = (!error && data && data.length > 0)
        ? data.map(r => ({
            time: new Date(r.recorded_at).getTime(),
            stress: Number(r.stress),
          }))
        : [];

      // Merge: use sample as base, replace with real readings where timestamps are close
      const merged = [...sample];
      for (const real of dbHistory) {
        // Find closest sample point and replace it, or append
        const idx = merged.findIndex(s => Math.abs(s.time - real.time) < 15 * 60 * 1000);
        if (idx >= 0) {
          merged[idx] = real;
        } else {
          merged.push(real);
        }
      }
      merged.sort((a, b) => a.time - b.time);

      const avg = merged.reduce((s, r) => s + r.stress, 0) / merged.length;
      setState(prev => ({
        ...prev,
        history: merged,
        dailyAverage: avg,
        loading: false,
      }));
    };

    loadTodayHistory();
  }, [user?.id, friendUserId, generateSampleData]);

  // Poll S3 for live data (only for self)
  const fetchStress = useCallback(async () => {
    if (friendUserId) return; // don't poll S3 for friends
    try {
      const response = await fetch(STRESS_URL, { cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      const trimmed = text.trim();
      // The S3 file may contain "timestamp value" format, e.g. "2026-02-14T17:49:00 0.15"
      const parts = trimmed.split(/\s+/);
      let stressVal = parseFloat(parts[parts.length - 1]); // take the last token as the stress value
      if (isNaN(stressVal)) throw new Error('Invalid stress value');
      // Normalize to 0-1 scale
      if (stressVal > 1) stressVal = stressVal / 100;
      stressVal = Math.min(1, Math.max(0, stressVal));

      const now = Date.now();

      // Save to DB
      if (user?.id) {
        supabase.from('stress_readings').insert({
          user_id: user.id,
          stress: stressVal,
        }).then(({ error }) => {
          if (error) console.error('Failed to save stress reading:', error);
        });
      }

      setState(prev => {
        const newHistory = [...prev.history, { time: now, stress: stressVal }].slice(-720);
        const avg = newHistory.reduce((s, r) => s + Math.min(1, Math.max(0, r.stress)), 0) / newHistory.length;
        return {
          stress: stressVal,
          loading: false,
          error: null,
          lastFetched: new Date().toISOString(),
          history: newHistory,
          dailyAverage: Math.min(1, Math.max(0, avg)),
        };
      });
    } catch (e) {
      setState(prev => ({
        ...prev,
        error: e instanceof Error ? e.message : 'Unknown error',
        loading: false,
      }));
    }
  }, [user?.id, friendUserId]);

  useEffect(() => {
    if (friendUserId) return; // don't poll for friends
    fetchStress();
    intervalRef.current = setInterval(fetchStress, POLL_INTERVAL);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [fetchStress, friendUserId]);

  return { ...state, refetch: fetchStress };
}
