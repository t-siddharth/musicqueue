# 🐍 Python Integration Setup Guide

This guide shows you how to connect the Focus Guardian extension to your Python script.

## What This Does

When you navigate away from your focus website, the extension will:
1. Show browser alerts (as before)
2. **Trigger your Python script** with the event data
3. Your Python script can do ANYTHING you want!

## Setup Steps

### Step 1: Prepare the Files

1. **Extract the extension** to a permanent location
   - Example: `C:\Users\YourName\focus-guardian\`
   - ⚠️ This folder must NOT move or be deleted!

2. **Make Python script executable**
   - The file `focus_handler.py` is your Python script
   - You can customize it to do whatever you want (see below)

### Step 2: Edit Configuration Files

#### A. Edit `com.focusguardian.host.json`

Open `com.focusguardian.host.json` and update these lines:

```json
{
  "name": "com.focusguardian.host",
  "description": "Focus Guardian Native Messaging Host",
  "path": "C:\\Users\\YourName\\focus-guardian\\focus_handler.bat",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://YOUR_EXTENSION_ID/"
  ]
}
```

**Replace:**
- `C:\\Users\\YourName\\focus-guardian\\focus_handler.bat` with YOUR actual path
  - ⚠️ Use double backslashes `\\` on Windows
  - ⚠️ Point to the `.bat` file, NOT the `.py` file
- `YOUR_EXTENSION_ID` with your actual extension ID
  - Find it in `chrome://extensions/` (looks like `abcdefghijklmnopqrstuvwxyz`)

#### B. Edit `install_host_windows.reg`

Open `install_host_windows.reg` and update:

```reg
Windows Registry Editor Version 5.00

[HKEY_CURRENT_USER\Software\Google\Chrome\NativeMessagingHosts\com.focusguardian.host]
@="C:\\Users\\YourName\\focus-guardian\\com.focusguardian.host.json"
```

**Replace:**
- `C:\\Users\\YourName\\focus-guardian\\` with YOUR actual path
- ⚠️ Use double backslashes `\\`

### Step 3: Install Python Requirements

Open Command Prompt and run:

```bash
pip install python-dateutil
```

(The basic script doesn't need any packages, but you'll need them for advanced features)

### Step 4: Register Native Messaging Host

1. **Double-click** `install_host_windows.reg`
2. Click **"Yes"** when Windows asks for permission
3. Click **"OK"** when it confirms

This registers the Python script with Chrome.

### Step 5: Test It!

1. **Reload the extension** in `chrome://extensions/`
2. Open the **DevTools Console** (F12)
3. **Navigate away** from your focus website
4. Check the console - you should see:
   ```
   ✅ Python script executed successfully
   ```

5. Check the log file:
   - Location: `C:\Users\YourName\focus-guardian-logs\focus_alerts.log`
   - Should contain your alerts!

## Customizing the Python Script

Open `focus_handler.py` and find the `on_focus_alert()` function. Add your custom code there!

### Example 1: Play a Sound

```python
def on_focus_alert(data):
    focus_domain = data.get('focusDomain')
    current_domain = data.get('currentDomain')
    
    # Play alert sound
    from playsound import playsound
    playsound('C:\\path\\to\\alert.mp3')
    
    return {"success": True}
```

Install: `pip install playsound`

### Example 2: Windows Desktop Notification

```python
def on_focus_alert(data):
    focus_domain = data.get('focusDomain')
    
    from win10toast import ToastNotifier
    toaster = ToastNotifier()
    toaster.show_toast(
        "Focus Alert!",
        f"You left {focus_domain}",
        duration=10,
        threaded=True
    )
    
    return {"success": True}
```

Install: `pip install win10toast`

### Example 3: Track to CSV

```python
def on_focus_alert(data):
    import csv
    import os
    
    csv_file = os.path.expanduser('~/focus_tracking.csv')
    
    with open(csv_file, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            datetime.datetime.now(),
            data.get('focusDomain'),
            data.get('currentDomain')
        ])
    
    return {"success": True}
```

### Example 4: Send to Discord Webhook

```python
def on_focus_alert(data):
    import requests
    
    webhook_url = 'YOUR_DISCORD_WEBHOOK_URL'
    
    requests.post(webhook_url, json={
        'content': f"🚨 Focus Alert! Left {data.get('focusDomain')}"
    })
    
    return {"success": True}
```

Install: `pip install requests`

### Example 5: Log to Database

```python
def on_focus_alert(data):
    import sqlite3
    
    conn = sqlite3.connect('focus_tracking.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS alerts
                 (timestamp TEXT, focus_site TEXT, distraction_site TEXT)''')
    
    c.execute("INSERT INTO alerts VALUES (?, ?, ?)",
              (datetime.datetime.now().isoformat(),
               data.get('focusDomain'),
               data.get('currentDomain')))
    
    conn.commit()
    conn.close()
    
    return {"success": True}
```

## Troubleshooting

### "Python script not configured"

- Check that `com.focusguardian.host.json` has the correct path
- Make sure the path uses double backslashes `\\`
- Verify the `.reg` file was installed (check Registry Editor)

### Script not running

1. Test manually:
   ```bash
   python focus_handler.py
   ```
   Type: `{"action": "ping"}`
   Press Enter twice
   Should respond with: `{"success": true, "message": "pong"}`

2. Check Python is in PATH:
   ```bash
   python --version
   ```

### Still not working?

- Check the log file: `~/focus-guardian-logs/focus_alerts.log`
- Look for errors in the extension console (F12 in background page)
- Make sure antivirus isn't blocking the script

## For macOS/Linux

Edit `com.focusguardian.host.json`:

```json
{
  "name": "com.focusguardian.host",
  "description": "Focus Guardian Native Messaging Host",
  "path": "/full/path/to/focus_handler.py",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://YOUR_EXTENSION_ID/"
  ]
}
```

Make script executable:
```bash
chmod +x focus_handler.py
```

Install host manifest:

**macOS:**
```bash
mkdir -p ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts/
cp com.focusguardian.host.json ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts/
```

**Linux:**
```bash
mkdir -p ~/.config/google-chrome/NativeMessagingHosts/
cp com.focusguardian.host.json ~/.config/google-chrome/NativeMessagingHosts/
```

## What Data Your Python Script Receives

```python
{
    "action": "focusAlert",
    "data": {
        "focusDomain": "youtube.com",
        "currentDomain": "reddit.com",
        "timestamp": "2026-02-14T22:45:30.123Z"
    }
}
```

You can use this data however you want in your Python script!

---

**Need help?** Check the console logs and the `focus_alerts.log` file for debugging info.
