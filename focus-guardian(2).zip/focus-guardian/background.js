// Background service worker for Focus Guardian

let focusWebsite = null;
let isMonitoring = false;
let originalTabId = null;

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'startMonitoring') {
    focusWebsite = message.website;
    originalTabId = message.tabId;
    isMonitoring = true;
    
    console.log('Started monitoring. Focus website:', focusWebsite);
    
    chrome.storage.local.set({
      focusWebsite: focusWebsite,
      isMonitoring: true,
      originalTabId: originalTabId
    });
    
    sendResponse({ success: true });
  } else if (message.action === 'stopMonitoring') {
    isMonitoring = false;
    focusWebsite = null;
    originalTabId = null;
    
    chrome.storage.local.set({
      isMonitoring: false,
      focusWebsite: null,
      originalTabId: null
    });
    
    console.log('Stopped monitoring');
    sendResponse({ success: true });
  } else if (message.action === 'getStatus') {
    sendResponse({
      isMonitoring: isMonitoring,
      focusWebsite: focusWebsite
    });
  }
  
  return true; // Keep message channel open for async response
});

// Load state on startup
chrome.storage.local.get(['focusWebsite', 'isMonitoring', 'originalTabId'], (result) => {
  if (result.isMonitoring) {
    focusWebsite = result.focusWebsite;
    isMonitoring = result.isMonitoring;
    originalTabId = result.originalTabId;
    console.log('Restored monitoring state:', { focusWebsite, isMonitoring });
  }
});

// Extract domain from URL
function getDomain(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch (e) {
    return null;
  }
}

// Check if URL is on the focus website
function isOnFocusWebsite(url) {
  if (!focusWebsite || !url) return true;
  
  const currentDomain = getDomain(url);
  const focusDomain = getDomain(focusWebsite);
  
  if (!currentDomain || !focusDomain) return true;
  
  // Check if domains match (including subdomains)
  return currentDomain === focusDomain || currentDomain.endsWith('.' + focusDomain);
}

// Show notification when user navigates away
function showAlert(tabId, url) {
  const currentDomain = getDomain(url);
  const focusDomain = getDomain(focusWebsite);
  
  // Create notification
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon128.png',
    title: '⚠️ Focus Alert!',
    message: `You've navigated away from ${focusDomain} to ${currentDomain}`,
    priority: 2,
    requireInteraction: true
  });
  
  // Update badge
  chrome.action.setBadgeText({ text: '!' });
  chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });
  
  console.log(`ALERT: Navigated from ${focusDomain} to ${currentDomain}`);
}

// Listen for tab updates (navigation)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!isMonitoring) return;
  
  // Only check when the page has finished loading
  if (changeInfo.status === 'complete' && tab.url) {
    // Ignore chrome:// and other internal pages
    if (tab.url.startsWith('chrome://') || 
        tab.url.startsWith('about:') || 
        tab.url.startsWith('edge://')) {
      return;
    }
    
    if (!isOnFocusWebsite(tab.url)) {
      showAlert(tabId, tab.url);
    } else {
      // Clear badge when back on focus website
      chrome.action.setBadgeText({ text: '' });
    }
  }
});

// Listen for tab activation (switching between tabs)
chrome.tabs.onActivated.addListener((activeInfo) => {
  if (!isMonitoring) return;
  
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab.url) {
      // Ignore internal pages
      if (tab.url.startsWith('chrome://') || 
          tab.url.startsWith('about:') || 
          tab.url.startsWith('edge://')) {
        return;
      }
      
      if (!isOnFocusWebsite(tab.url)) {
        showAlert(activeInfo.tabId, tab.url);
      } else {
        chrome.action.setBadgeText({ text: '' });
      }
    }
  });
});

console.log('Focus Guardian background service worker loaded');
