# 🎯 Focus Guardian - Browser Extension

A browser extension that helps you stay focused by alerting you when you navigate away from your designated focus website.

## Features

- ✅ **One-Click Activation**: Start monitoring from any webpage
- 🚨 **Instant Alerts**: Get notifications when you leave your focus site
- 🎨 **Visual Badge**: See a red "!" badge when you're off-track
- 💾 **Persistent**: Remembers your focus site even after closing the browser
- 🌐 **Domain-Based**: Works across all pages of the same website

## Installation

### Chrome/Edge

1. **Download the extension folder** containing all files
2. **Open your browser** and go to:
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`
3. **Enable "Developer mode"** (toggle in top-right corner)
4. **Click "Load unpacked"**
5. **Select the `focus-guardian` folder**
6. The extension is now installed! 🎉

### Firefox

1. **Download the extension folder**
2. **Open Firefox** and go to: `about:debugging#/runtime/this-firefox`
3. **Click "Load Temporary Add-on"**
4. **Select the `manifest.json` file** from the `focus-guardian` folder
5. The extension is now installed! 🎉

## How to Use

### Start Monitoring

1. **Navigate to the website** you want to focus on (e.g., your work dashboard, study platform)
2. **Click the Focus Guardian icon** in your browser toolbar
3. **Click "Start Focus"** button
4. ✅ You're now being monitored!

### What Happens

- **Stay on the focus site**: No alerts, smooth work
- **Navigate away**: You'll get:
  - 🔔 A browser notification
  - 🔴 A red "!" badge on the extension icon
  - 📝 A log in the browser console

### Stop Monitoring

1. **Click the Focus Guardian icon**
2. **Click "Stop Focus"** button
3. ✅ Monitoring stopped

## Examples

### Example 1: Focus on Work
- Start monitoring on `app.company.com`
- Work on different pages: `app.company.com/dashboard`, `app.company.com/reports` → ✅ No alert
- Open `reddit.com` → 🚨 **ALERT!**

### Example 2: Study Session
- Start monitoring on `canvas.instructure.com` (learning management system)
- Navigate through course pages → ✅ No alert
- Check `youtube.com` → 🚨 **ALERT!**

## Files

```
focus-guardian/
├── manifest.json       # Extension configuration
├── background.js       # Background service worker (monitors tabs)
├── popup.html          # Extension popup UI
├── popup.js           # Popup logic
├── icon16.png         # Icon (16x16)
├── icon48.png         # Icon (48x48)
├── icon128.png        # Icon (128x128)
└── README.md          # This file
```

## How It Works

1. **Background Service Worker**: Monitors all tab changes and navigations
2. **Domain Matching**: Compares current tab's domain with your focus website
3. **Alert System**: Triggers notifications when domains don't match
4. **Persistent Storage**: Saves your focus website using Chrome Storage API

## Permissions Explained

- **tabs**: To monitor which tabs are active
- **activeTab**: To get the current tab's URL
- **storage**: To remember your focus website
- **notifications**: To show alerts
- **host_permissions**: To monitor all websites

## Privacy

- ✅ All data stays **local** on your device
- ✅ No data is sent to any server
- ✅ No tracking or analytics
- ✅ Open source code - see exactly what it does

## Troubleshooting

**Extension not working?**
- Make sure you clicked "Start Focus" in the popup
- Check that you're not on a `chrome://` or `about:` page (can't monitor these)
- Try reloading the extension in `chrome://extensions/`

**Not getting notifications?**
- Check your browser notification permissions
- Make sure notifications are enabled for your browser in system settings

**Badge not clearing?**
- Navigate back to your focus website
- The badge should clear automatically

## Tips

- Use this for focused work sessions (Pomodoro technique)
- Set it on your productivity tools to avoid social media
- Great for studying - set it on your course platform
- Helps build awareness of browsing habits

## License

MIT License - Feel free to modify and use!

---

Made with ❤️ to help you stay focused
