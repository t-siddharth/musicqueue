#!/usr/bin/env python3
"""
Focus Guardian - Python Handler
This script is triggered when you navigate away from your focus website
"""

import sys
import json
import struct
import datetime
import os

def send_message(message):
    """Send a message back to the extension"""
    encoded_message = json.dumps(message).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('I', len(encoded_message)))
    sys.stdout.buffer.write(encoded_message)
    sys.stdout.buffer.flush()

def read_message():
    """Read a message from the extension"""
    text_length_bytes = sys.stdin.buffer.read(4)
    if len(text_length_bytes) == 0:
        sys.exit(0)
    
    text_length = struct.unpack('I', text_length_bytes)[0]
    text = sys.stdin.buffer.read(text_length).decode('utf-8')
    return json.loads(text)

def log_to_file(message):
    """Log events to a file for debugging"""
    log_dir = os.path.expanduser('~/focus-guardian-logs')
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, 'focus_alerts.log')
    
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")

def on_focus_alert(data):
    """
    Handle focus alert - YOU CAN CUSTOMIZE THIS!
    
    This function is called when you navigate away from your focus website.
    Add your custom logic here!
    """
    focus_domain = data.get('focusDomain', 'unknown')
    current_domain = data.get('currentDomain', 'unknown')
    
    # Log the event
    message = f"FOCUS ALERT: Left '{focus_domain}' -> Now on '{current_domain}'"
    log_to_file(message)
    
    # Print to console (will appear in extension logs)
    print(f"\n{'='*60}", file=sys.stderr)
    print(f"🚨 FOCUS GUARDIAN ALERT!", file=sys.stderr)
    print(f"{'='*60}", file=sys.stderr)
    print(f"You left: {focus_domain}", file=sys.stderr)
    print(f"Now on: {current_domain}", file=sys.stderr)
    print(f"Time: {datetime.datetime.now().strftime('%I:%M:%S %p')}", file=sys.stderr)
    print(f"{'='*60}\n", file=sys.stderr)
    
    # ============================================
    # ADD YOUR CUSTOM CODE HERE!
    # ============================================
    
    # Example 1: Play a sound (requires pygame or playsound)
    # try:
    #     from playsound import playsound
    #     playsound('alert.mp3')
    # except:
    #     pass
    
    # Example 2: Send a desktop notification (Windows)
    # try:
    #     from win10toast import ToastNotifier
    #     toaster = ToastNotifier()
    #     toaster.show_toast(
    #         "Focus Alert!",
    #         f"You left {focus_domain}",
    #         duration=5
    #     )
    # except:
    #     pass
    
    # Example 3: Append to a CSV file for tracking
    # import csv
    # csv_file = os.path.expanduser('~/focus-guardian-logs/tracking.csv')
    # with open(csv_file, 'a', newline='') as f:
    #     writer = csv.writer(f)
    #     writer.writerow([
    #         datetime.datetime.now().isoformat(),
    #         focus_domain,
    #         current_domain
    #     ])
    
    # Example 4: Send to a webhook/API
    # import requests
    # requests.post('https://your-api.com/focus-alert', json=data)
    
    # Example 5: Increment a counter
    # counter_file = os.path.expanduser('~/focus-guardian-logs/distraction_count.txt')
    # try:
    #     with open(counter_file, 'r') as f:
    #         count = int(f.read().strip())
    # except:
    #     count = 0
    # count += 1
    # with open(counter_file, 'w') as f:
    #     f.write(str(count))
    # print(f"Total distractions today: {count}", file=sys.stderr)
    
    return {"success": True, "message": "Alert handled"}

def main():
    """Main message loop"""
    try:
        while True:
            message = read_message()
            
            action = message.get('action')
            
            if action == 'focusAlert':
                response = on_focus_alert(message.get('data', {}))
                send_message(response)
            
            elif action == 'ping':
                send_message({"success": True, "message": "pong"})
            
            else:
                send_message({"success": False, "error": "Unknown action"})
    
    except Exception as e:
        log_to_file(f"ERROR: {str(e)}")
        send_message({"success": False, "error": str(e)})

if __name__ == '__main__':
    main()
